package controllers;

import play.mvc.*;
import views.html.*;
import models.Product;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {
        return ok(index.render("Hello World!"));
    }

    public Result menu() {
        return ok(menu.render());
    }

    public Result order() {

        // Create a new product
        Product p = new Product();

        //Set the properties for p
        p.setId(1L);
        p.setName("Meat");
        p.setCategory("Burgers");
        p.setStock(400);
        p.setPrice(2.50);
        
        
        return ok(order.render(p));
    }

    public Result signin() {
        return ok(signin.render());
    }
}
