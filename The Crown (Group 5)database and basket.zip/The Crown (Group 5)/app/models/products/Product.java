package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Product {

    //Properties
    @Id
    private Long id;

    @Constraints.Required
    private String name;

    @Constraints.Required
    private String category;

    @Constraints.Required
    private String stock;

    @Constraints.Min(0)
    private double price;


//Constructors
public Product(){

}

public Product(Long id, String name, String catrgory, String stock, double price){
    this.id = id;
    this.name = name;
    this.category = category;
    this.stock = stock;
    this.price = price;
}

//Query helper
public static Finder<Long,Product> find = new Finder<>(Product.class);

// Accessor methods
public Long getId() {
    return this.id;
}

public void setId(Long id){
    this.id = id;
}

public String getName() {
    return this.name;
}

public void setName(String name){
    this.name = name;
}

public String getCategory() {
    return this.category;
}

public void setCategory(String category){
    this.category = category;
}


public String getStock() {
    return this.stock;
}

public void setStock(String stock){
    this.stock = stock;
}

public Double getPrice() {
    return this.price;
}

public void setPrice(double price){
    this.price = price;
}



}

