# -- sample dataset

# -- !Ups




insert into product (id,name,category,stock,price) values ( 1,'Meat', 'Burgers', 'Yes', 2);
insert into product (id,name,category,stock,price) values ( 2,'Bun', 'Burgers', 'Yes', 1);
insert into product (id,name,category,stock,price) values ( 3,'Bacon', 'BUrgers', 'Yes', 1);
insert into product (id,name,category,stock,price) values ( 4,'Tomato', 'Burgers', 'Yes', 0.50);
insert into product (id,name,category,stock,price) values ( 5,'Cheese', 'Burgers', 'Yes', 0.50);
insert into product (id,name,category,stock,price) values ( 6,'Coleslaw', 'Burgers', 'Yes', 0.50);
insert into product (id,name,category,stock,price) values ( 7,'Lettuce', 'Burgers', 'Yes', 0.50);
insert into product (id,name,category,stock,price) values ( 8,'Onion', 'Burgers', 'Yes', 0.50);
insert into product (id,name,category,stock,price) values ( 9,'Pickles', 'Burgers', 'Yes', 0.50);
insert into product (id,name,category,stock,price) values ( 10,'BBQ', 'Burgers', 'Yes', 0.25);
insert into product (id,name,category,stock,price) values ( 11,'Mayo', 'Burgers', 'Yes', 0.25);
insert into product (id,name,category,stock,price) values ( 12,'Ketchup', 'Burgers', 'Yes', 0.25);

insert into product (id,name,category,stock,price) values ( 13,'Small', 'Fries', 'Yes', 1.50);
insert into product (id,name,category,stock,price) values ( 14,'Medium', 'Fries', 'Yes', 2);
insert into product (id,name,category,stock,price) values ( 15,'Large', 'Fries', 'Yes', 2.50);

insert into product (id,name,category,stock,price) values ( 16,'Coke', 'Drinks', 'Yes', 1.20);
insert into product (id,name,category,stock,price) values ( 17,'Diet Coke', 'Drinks', 'Yes', 1.20);
insert into product (id,name,category,stock,price) values ( 18,'Coke Zero', 'Drinks', 'Yes', 1.20);
insert into product (id,name,category,stock,price) values ( 19,'Fanta Orange', 'Drinks', 'Yes', 1.20);
insert into product (id,name,category,stock,price) values ( 20,'Sprite', 'Drinks', 'Yes', 1.20);
insert into product (id,name,category,stock,price) values ( 21,'Strawberry Milkshake', 'Drinks', 'Yes', 2);
insert into product (id,name,category,stock,price) values ( 22,'Chocolate Milkshake', 'Drinks', 'Yes', 2);
insert into product (id,name,category,stock,price) values ( 23,'Vanilla Milkshake', 'Drinks', 'Yes', 2);
insert into product (id,name,category,stock,price) values ( 24,'Tea', 'Drinks', 'Yes', 1.50);
insert into product (id,name,category,stock,price) values ( 25,'Latte', 'Drinks', 'Yes', 2);
insert into product (id,name,category,stock,price) values ( 26,'Mocha', 'Drinks', 'Yes', 2);

